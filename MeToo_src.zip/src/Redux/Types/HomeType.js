//--->>Types for get Post---->>>
export const GETPOST_REQUESTING = 'GETPOST_REQUESTING';
export const GETPOST_SUCCESS = 'GETPOST_SUCCESS';
export const GETPOST_FAIL = 'GETPOST_FAIL';

//--->>Types for get Post Images---->>>
export const GETIMAGES_REQUESTING = 'GETIMAGES_REQUESTING';
export const GETIMAGES_SUCCESS = 'GETIMAGES_SUCCESS';
export const GETIMAGES_FAIL = 'GETIMAGES_FAIL';