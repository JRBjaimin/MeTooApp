//--->>Types for Category---->>>
export const CATEGORY_REQUESTING = 'CATEGORY_REQUESTING';
export const CATEGORY_SUCCESS = 'CATEGORY_SUCCESS';
export const CATEGORY_FAIL = 'CATEGORY_FAIL';