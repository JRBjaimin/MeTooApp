import {
    REGISTER_FAIL,
    REGISTER_SUCCESS,
} from '../Types/AuthType';

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('---- Auth Reducer Register:')
    switch (action.type) {
        case REGISTER_SUCCESS:
            return { ...state, registration_Success: true, registrationData: action.payload };

        case REGISTER_FAIL:
            return { ...state, registration_Success: false, error: action.payload };

        default:
            return state;
    };
};