import {
    GETPOST_SUCCESS,
    GETPOST_FAIL,

    GETIMAGES_SUCCESS,
    GETIMAGES_FAIL
} from '../Types/HomeType';

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('----Home Reducer:')
    switch (action.type) {
        //...getPost..............
        case GETPOST_SUCCESS:
            return { ...state, getPost_Success: true, getPostData: action.payload };

        case GETPOST_FAIL:
            return { ...state, getPost_Success: false, error: action.payload };

        //...getPostImage.............. 
        case GETIMAGES_SUCCESS:
            return { ...state, getImages_Success: true, getImageData: action.payload };

        case GETIMAGES_FAIL:
            return { ...state, getImages_Success: false, error: action.payload }

        default:
            return state;
    };
};
