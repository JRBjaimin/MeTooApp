import {
    ENCRYPT_TOKEN_SUCCESS,
    ENCRYPT_TOKEN_FAIL,
} from '../Types/AuthType';

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('---- Auth Reducer Encryption:')
    switch (action.type) {
        case ENCRYPT_TOKEN_SUCCESS:
            return { ...state, encryptToken_Success: true, encryptData: action.payload };

        case ENCRYPT_TOKEN_FAIL:
            return { ...state, encryptToken_Success: false, error: action.payload };

        default:
            return state;
    };
};