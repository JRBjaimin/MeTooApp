import {
    REFRESH_TOKEN_SUCCESS,
    REFRESH_TOKEN_FAIL,

    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,

    FORGOT_PASSWORD_SUCCESS,
    FORGOT_PASSWORD_FAIL,

    GUEST_USER_SUCCESS,
    GUEST_USER_FAIL,
} from '../Types/AuthType';

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('---- Auth Reducer:')
    switch (action.type) {

        case REFRESH_TOKEN_SUCCESS:
            return { ...state, refreshToken_Success: true, refreshTokenData: action.payload };

        case REFRESH_TOKEN_FAIL:
            return { ...state, refreshToken_Success: false, error: action.payload };


        case LOGIN_USER_SUCCESS:
            return { ...state, login_Success: true, loginData: action.payload };

        case LOGIN_USER_FAIL:
            return { ...state, login_Success: false, error: action.payload };


        case FORGOT_PASSWORD_SUCCESS:
            return { ...state, forgotPwd_Success: true, forgotPwdData: action.payload };

        case FORGOT_PASSWORD_FAIL:
            return { ...state, forgotPwd_Success: false, error: action.payload };


        case GUEST_USER_SUCCESS:
            return { ...state, guestUser_Success: true, guestData: action.payload };

        case GUEST_USER_FAIL:
            return { ...state, guestUser_Success: false, error: action.payload };

        default:
            return state;
    };
};