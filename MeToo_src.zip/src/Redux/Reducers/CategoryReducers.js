import {
    CATEGORY_SUCCESS,
    CATEGORY_FAIL,
} from '../Types/CategoryType';

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('---- Category Reducer:')
    switch (action.type) {
        case CATEGORY_SUCCESS:
            return { ...state, category_Success: true, categoryData: action.payload };

        case CATEGORY_FAIL:
            return { ...state, category_Success: false, error: action.payload };

        default:
            return state;
    };
};