import { combineReducers } from 'redux';

import AuthReducer from './AuthReducers';
import EncryptionReducers from './EncryptionReducers';
import RegisterReducer from './RegisterReducer';
import CategoryReducers from './CategoryReducers';
import HomeReducers from './HomeReducers';

let appReducer = combineReducers({
  Auth: AuthReducer,
  Encryption: EncryptionReducers,
  Register: RegisterReducer,
  Category: CategoryReducers,
  Home: HomeReducers,
});

const rootReducer = (state, action) => {
  return appReducer(state, action)
}

export default rootReducer;
