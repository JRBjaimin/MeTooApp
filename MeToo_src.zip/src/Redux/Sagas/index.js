import { all } from 'redux-saga/effects';

import watchAuth from './AuthSagas';
import watchCategory from './CategorySaga';
import watchHome from './HomeSagas';

// Root Saga
const rootSaga = function* rootSaga() {
    yield all([
        watchAuth(),
        watchCategory(),
        watchHome(),
    ])
};

export default rootSaga;