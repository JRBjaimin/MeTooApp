//LIBRARIES
import { put, call, all, takeEvery } from 'redux-saga/effects';

import {
    GETPOST_REQUESTING,
    GETPOST_SUCCESS,
    GETPOST_FAIL,

    GETIMAGES_REQUESTING,
    GETIMAGES_SUCCESS,
    GETIMAGES_FAIL,
} from '../Types/HomeType';

import Api from '../../Config/Api';

/************************ Get Post ****************************/
export const watchGetPostAsync = function* watchGetPostAsync({ params }) {
    console.log(params)
    try {
        console.log('----Home Get Post SAGA calling:')
        const response = yield call(Api.getPostsByCategory, params)
        console.log('Home Get Post response:', response)
        yield put({ type: GETPOST_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: GETPOST_FAIL, payload: e });
    }
}

/************************ Get Post Images ****************************/
export const watchGetImagesAsync = function* watchGetImagesAsync({ params }) {
    console.log(params)
    try {
        console.log('----Home Get Post Images SAGA calling:')
        const response = yield call(Api.getPostImages, params)
        console.log('Home Get Post Images response:', response)
        yield put({ type: GETIMAGES_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: GETIMAGES_FAIL, payload: e });
    }
}

const watchHome = function* watchHome() {

    yield takeEvery(GETPOST_REQUESTING, watchGetPostAsync)
    yield takeEvery(GETIMAGES_REQUESTING, watchGetImagesAsync)
}

export default watchHome;