//LIBRARIES
import { put, call, all, takeEvery } from 'redux-saga/effects';

import {
    REFRESH_TOKEN_REQUESTING,
    REFRESH_TOKEN_SUCCESS,
    REFRESH_TOKEN_FAIL,

    ENCRYPT_TOKEN_REQUESTING,
    ENCRYPT_TOKEN_SUCCESS,
    ENCRYPT_TOKEN_FAIL,

    LOGIN_USER_REQUESTING,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,

    REGISTER_REQUESTING,
    REGISTER_SUCCESS,
    REGISTER_FAIL,

    FORGOT_PASSWORD_REQUESTING,
    FORGOT_PASSWORD_SUCCESS,
    FORGOT_PASSWORD_FAIL,

    GUEST_USER_REQUESTING,
    GUEST_USER_SUCCESS,
    GUEST_USER_FAIL,

} from '../Types/AuthType';

import Api from '../../Config/Api';

/************************ Refresh Token Saga ****************************/
export const watchrefreshTokenAsync = function* watchrefreshTokenAsync({ params }) {
    console.log(params, 'saga for verification')
    try {
        console.log('--------------- Refresh SAGA CALLING')
        const response = yield call(Api.RefreshToken, params)
        console.log(response, 'refreshTok====')
        yield put({ type: REFRESH_TOKEN_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: REFRESH_TOKEN_FAIL, payload: e });
    }
}

/************************ Encrypt Token Saga ****************************/
export const watchEncryptTokenAsync = function* watchEncryptTokenAsync({ params }) {
    console.log(params, 'saga for encrypt')
    try {
        console.log('---------------Encrypt SAGA CALLING')
        const response = yield call(Api.TestEncryption, params)
        console.log("Encrypt resdpnse::",response)
        yield put({ type: ENCRYPT_TOKEN_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: ENCRYPT_TOKEN_FAIL, payload: e });
    }
}

/************************ Login function ****************************/
export const watchLoginAsync = function* watchLoginAsync({ params }) {
    console.log(params)
    try {
        console.log('---- Login SAGA calling:')
        const response = yield call(Api.userLogin, params)
        console.log('response:', response)
        yield put({ type: LOGIN_USER_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: LOGIN_USER_FAIL, payload: e });
    }
}

/************************ Register function ****************************/
export const watchRegisterAsync = function* watchRegisterAsync({ params }) {
    console.log(params)
    try {
        console.log('---- Register SAGA calling:')
        const response = yield call(Api.Register, params)
        console.log('response:', response)
        yield put({ type: REGISTER_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: REGISTER_FAIL, payload: e });
    }
}

/************************ Forgot Password ****************************/
export const watchFogotAsync = function* watchFogotAsync({ params }) {
    console.log(params)
    try {
        console.log('---- Forgot Password SAGA calling:')
        const response = yield call(Api.forgotPassword, params)
        console.log('response:', response)
        yield put({ type: FORGOT_PASSWORD_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: FORGOT_PASSWORD_FAIL, payload: e });
    }
}

/************************ Guest User ****************************/
export const watchGuestAsync = function* watchGuestAsync({ params }) {
    console.log(params)
    try {
        console.log('---- Guest User SAGA calling:')
        const response = yield call(Api.registerAsGuestUser, params)
        console.log('response:', response)
        yield put({ type: GUEST_USER_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: GUEST_USER_FAIL, payload: e });
    }
}

const watchAuth = function* watchAuth() {
    yield takeEvery(REFRESH_TOKEN_REQUESTING, watchrefreshTokenAsync)
    yield takeEvery(ENCRYPT_TOKEN_REQUESTING, watchEncryptTokenAsync)
    yield takeEvery(LOGIN_USER_REQUESTING, watchLoginAsync)
    yield takeEvery(REGISTER_REQUESTING, watchRegisterAsync)
    yield takeEvery(FORGOT_PASSWORD_REQUESTING, watchFogotAsync)
    yield takeEvery(GUEST_USER_REQUESTING, watchGuestAsync)
}

export default watchAuth;