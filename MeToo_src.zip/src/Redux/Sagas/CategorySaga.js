//LIBRARIES
import { put, call, all, takeEvery } from 'redux-saga/effects';

import {
    CATEGORY_REQUESTING,
    CATEGORY_SUCCESS,
    CATEGORY_FAIL,
} from '../Types/CategoryType';

import Api from '../../Config/Api';

/************************ Category List ****************************/
export const watchCategoryAsync = function* watchCategoryAsync({ params }) {
    console.log(params)
    try {
        console.log('---- Category List SAGA calling:')
        const response = yield call(Api.getCategory, params)
        console.log('response:', response)
        yield put({ type: CATEGORY_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: CATEGORY_FAIL, payload: e });
    }
}

const watchCategory = function* watchCategory() {

    yield takeEvery(CATEGORY_REQUESTING, watchCategoryAsync)
}

export default watchCategory;