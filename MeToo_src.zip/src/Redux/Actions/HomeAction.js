import {
    GETPOST_REQUESTING,
    GETIMAGES_REQUESTING,
} from '../Types/HomeType';

//--->>Request getPost ---->>>>>
export const getPostRequest = (params) => {
    console.log('Action for getPostRequest', params)
    return {
        type: GETPOST_REQUESTING,
        params
    };
}

//--->>Request getPostImages ---->>>>>
export const getPostImagesRequest = (params) => {
    console.log('Action for getPostImagesRequest', params)
    return {
        type: GETIMAGES_REQUESTING,
        params
    };
}