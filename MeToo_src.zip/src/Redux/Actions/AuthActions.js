import {
    REFRESH_TOKEN_REQUESTING,
    ENCRYPT_TOKEN_REQUESTING,
    LOGIN_USER_REQUESTING,
    REGISTER_REQUESTING,
    FORGOT_PASSWORD_REQUESTING,
    GUEST_USER_REQUESTING
} from '../Types/AuthType';

//--->>Request Refresh Token----->>>>>
export const refreshTokenRequest = (params) => {
    console.log('Action for refresh token', params)
    return {
        type: REFRESH_TOKEN_REQUESTING,
        params
    };
}

//--->>Request Encrypt Token----->>>>>
export const encryptTokenRequest = (params) => {
    console.log('Action for encryption token', params)
    return {
        type: ENCRYPT_TOKEN_REQUESTING,
        params
    };
}

//--->>Request Login----->>>>> 
export const loginRequest = (params) => {
    console.log('loginRequest Action:', params);
    return {
        type: LOGIN_USER_REQUESTING,
        params
    };
}

//--->>Request Register----->>>>> 
export const registerRequest = (params) => {
    console.log('Action for Register Request:', params);
    return {
        type: REGISTER_REQUESTING,
        params
    };
}

//--->>Request Register----->>>>> 
export const forgotPasswordRequest = (params) => {
    console.log('Action for forgot Password Request:', params);
    return {
        type: FORGOT_PASSWORD_REQUESTING,
        params
    };
}

//--->>Guest Register----->>>>> 
export const guestUserRequest = (params) => {
    console.log('Action for guestUser Request Request:', params);
    return {
        type: GUEST_USER_REQUESTING,
        params
    };
}

