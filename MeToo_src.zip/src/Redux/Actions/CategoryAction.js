import {
    CATEGORY_REQUESTING,
} from '../Types/CategoryType';

//--->>Request Refresh Token----->>>>>
export const categoryRequest = (params) => {
    console.log('Action for categoryRequest', params)
    return {
        type: CATEGORY_REQUESTING,
        params
    };
}