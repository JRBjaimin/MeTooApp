import React, { Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import AppNavigation from './AppNavigation';
// import { store, persistor } from './store';
import { Store, Persistor } from './store/index';



class app extends Component {
    constructor(props) {
        super(props)
        console.disableYellowBox = true;
    }

    render() {
        return (
            <Provider store={Store}>
                <PersistGate persistor={Persistor}>
                    <View style={{ flex: 1 }}>
                        <AppNavigation key="appNavigation" />
                    </View>
                </PersistGate>
            </Provider>
            

            // <View style={{ flex: 1 }}>
            //     {/* <Text>App !!!!!!!!</Text> */}
            //     <AppNavigation key="appNavigation" />
            // </View>
        );
    }
};

const styles = StyleSheet.create({});

export default app;