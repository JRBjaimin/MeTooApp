import React, { Component } from 'react';
import { Text, View, StyleSheet, ScrollView, SafeAreaView, Image, FlatList, Dimensions, TouchableOpacity } from 'react-native';
import { Colors, Images, Matrics } from '../../Assets';
import { Card } from 'react-native-elements';

var array = [
    { title: "Bullying", icon: Images.icon_Bully },
    { title: "Cyber Attack", icon: Images.icon_cyber_attack },
    { title: "Discrimination", icon: Images.icon_discriminstion },
    { title: "Sexual Harassment", icon: Images.icon_Sexual_Harassment },
    { title: "Verbal Abuse", icon: Images.icon_Abuse },
    { title: "Violence", icon: Images.icon_violence }
]

class NotificationScreen extends Component {

    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Notification',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        // headerBackTitle: null
    });


    renderItem() {
        return array.map((item,index) => {
            const { title, } = item;
 
            return (
                <Card key={index}
                    containerStyle={{
                        borderWidth: 0,
                        borderBottomColor: Colors.TEXTCOLOR,
                        borderBottomWidth: 0.3,
                        backgroundColor: 'black'
                    }}>

                    <View style={{ flexDirection: 'row' }}>

                        <View style={styles.mainView}>
                            <Image
                                source={Images.user}
                                resizeMode='contain'
                                style={styles.imageStyle}
                            />
                            <Text style={styles.italics}>{title} </Text>
                            <Text style={styles.commentitalics}>comment</Text>
                        </View>

                        <View style={styles.timeViewStyle}>
                            <Text style={{ color: Colors.TEXTCOLOR, fontSize: 12 }}>00:00 pm</Text>
                        </View>

                    </View>
                </Card>
            );
        })
    }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'black' }}>
                {/* <Header
                    headerText="Notification"
                    onPress={() => this.props.navigation.navigate('CategoryScreen')}
                /> */}
                <ScrollView>
                    {this.renderItem()}
                </ScrollView>
            </View>
        );
    }
};

const styles = StyleSheet.create({
    mainView: {
        flex: 0.7,
        flexDirection: 'row',
        // backgroundColor: 'red',
        alignItems: 'center',
        // justifyContent: 'flex-start',
    },
    timeViewStyle: {
        flex: 0.3,
        alignItems: 'flex-end'
    },
    italics: {
        color: Colors.TEXTCOLOR,
        fontSize: 15
    },
    commentitalics: {
        color: Colors.TEXTCOLOR,
        fontSize: 13
    },
    imageStyle: {
        width: Matrics.Scale(50), marginRight: 10
    },
    headerStyleNav: {
        flex: 1,
        color: Colors.WHITE,
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
});

export default NotificationScreen;