import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, FlatList, Platform, ScrollView, Dimensions, TouchableOpacity, ImageBackground } from 'react-native';
import { Colors, Images, Matrics } from '../../Assets';
import { Card } from 'react-native-elements';

import { connect } from 'react-redux'
import { URLProfileImage, URLFeedImage } from '../../Config/Constants';
import { LoadWheel } from '../../components/common/LoadWheel';
import { PhotoCardSection } from '../../components/common';
import { getPostRequest, getPostImagesRequest } from '../../Redux/Actions';
import TimeAgo from 'react-native-timeago';
import ViewMoreText from 'react-native-view-more-text';
import Lightbox from 'react-native-lightbox';


let deviceType = Platform.OS == 'ios' ? 1 : 0;
const { width, height } = Dimensions.get('window');

var array = [
    { title: "Bullying", icon: Images.icon_Bully },
    { title: "Cyber Attack", icon: Images.icon_cyber_attack },
    { title: "Discrimination", icon: Images.icon_discriminstion },
    { title: "Sexual Harassment", icon: Images.icon_Sexual_Harassment },
    { title: "Verbal Abuse", icon: Images.icon_Abuse },
    { title: "Violence", icon: Images.icon_violence }
]

class HomeScreen extends Component {
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Me Too',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        headerLeft:
            <TouchableOpacity onPress={() => navigation.navigate('CategoryScreen')}
                style={{ padding: Matrics.Scale(15) }}>
                <Image source={Images.icon_List} ></Image>
            </TouchableOpacity>,
        headerRight: <TouchableOpacity onPress={() => navigation.navigate('PinterestLayoutScreen')}
            style={{ padding: Matrics.Scale(15) }}>
            <Image source={Images.icon_layout} resizeMode='contain' style={styles.headerImage}></Image>
        </TouchableOpacity>,
        headerBackTitle: null
    });

    constructor(props) {
        super(props),
            this.state = {
                isLoading: false,
                isPhotosLoading: false,
                // CategoryId: this.props.navigation.state.params.dataFromId.id,
                CategoryId: "2",
                UserId: this.props.auth.loginData.data.User.id,
                // PostOf:"",greed
                isPhotoVisible: true,
                PostData: [],
                PostImages: []
            }
    }

    async componentDidMount() {
        if (this.props.navigation.state.params.dataFromId) {
            await this.setState({ CategoryId: this.props.navigation.state.params.dataFromId.id })
            console.log("in if condition CategoryId:", this.state.CategoryId);
        }
        await this.getImagesRequest();
        await this.getPostRequest();
    }

    async componentWillReceiveProps(nextProps) {
        console.log("Home NextProps:", nextProps);
        console.log("Home this.state.isLoading:", this.state.isLoading);
        console.log("Home this.state.isPhotosLoading:", this.state.isPhotosLoading);

        //......GetPostImages api Recive
        if (nextProps.home.getImages_Success && nextProps.home.getImageData.status == "1" && this.state.isPhotosLoading) {
            await this.setState({ isPhotosLoading: false, PostImages: nextProps.home.getImageData.data.post_media })
            console.log("PostImages:", this.state.PostImages);
        } else if (nextProps.home.getImages_Success && nextProps.home.getImageData.status == "0" && this.state.isPhotosLoading) {
            this.setState({ isPhotosLoading: false })
            alert(nextProps.home.getImageData.message)
        } else if (nextProps.home.getImages_Success == false) {
            this.setState({ isPhotosLoading: false })
            alert(nextProps.home.getImageData.message)
        }

        // .....GetPost api Recive
        if (nextProps.home.getPost_Success && nextProps.home.getPostData.status == "1" && this.state.isLoading) {
            await this.setState({ isLoading: false, PostData: nextProps.home.getPostData.data.posts })
            console.log("PostData:", this.state.PostData);
        } else if (nextProps.home.getPost_Success && nextProps.home.getPostData.status == "0" && this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(nextProps.home.getPostData.message)
        } else if (nextProps.home.getPost_Success == false) {
            await this.setState({ isLoading: false })
            alert(nextProps.home.getPostData.message)
        }


    }

    // when flatelist is empty the display "NO DATA FOUND">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    loadEmptyView = () => {
        console.log("Empty List");
        return (
            <View style={styles.emptyListView}>
                <Text
                    style={styles.emptyText}>
                    No Data Found
                    </Text>
            </View>
        );
    }

    renderViewMore(onPress) {
        return (
            <Text style={styles.viewMoreStyle} onPress={onPress}>View more</Text>
        )
    }
    renderViewLess(onPress) {
        return (
            <Text style={styles.viewMoreStyle} onPress={onPress}>View less</Text>
        )
    }

    //...GetPostImages API request
    async getImagesRequest() {
        console.log("getImagesRequest this.props", this.props);
        this.setState({ isPhotosLoading: true })

        this.props.getPostImagesRequest({
            secret_key: this.props.auth.loginData.userToken,
            access_key: this.props.encrypt.encryptData.encrypted_value,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.state.UserId,
            post_of: "0",
            offset: "0",
            category_id: this.state.CategoryId,
            is_testdata: "1"
        })
    }

    //...GetPost API request
    async getPostRequest() {
        console.log("getPostRequest this.props", this.props);
        this.setState({ isLoading: true })
        this.props.getPostRequest({
            secret_key: this.props.auth.loginData.userToken,
            access_key: this.props.encrypt.encryptData.encrypted_value,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.state.UserId,
            post_of: "0",
            offset: "0",
            category_id: this.state.CategoryId,
            is_testdata: "1"
        })
    }

    rendarItem() {
        console.log('renderItem PostData:', this.state.PostData);

        return this.state.PostData.map((item, index) => {
            console.log("item", item);
            console.log('logprofile_photo:', URLProfileImage + item.profile_photo);
            // console.log('logURLFeedImage:', URLFeedImage + item.post_media[0].media_name);
            let timestamp = item.modified_date;
            let description = item.description;
            let profile_photo = URLProfileImage + item.profile_photo

            return (
                <Card
                    key={index}
                    containerStyle={styles.cardStyle2}>

                    <View style={{ flexDirection: 'row' }}>

                        <View>
                            {/* <TouchableOpacity
                                // style={{ backgroundColor: 'yellow' }}
                                onPress={() => { }}> */}
                            <Image
                                source={{ uri: profile_photo }}
                                style={styles.profileStyle}
                                resizeMode='contain'
                            />
                            {/* </TouchableOpacity> */}
                        </View>


                        <View style={{ marginLeft: 10, flex: 1, }}>
                            {/* .........first text line.......... */}
                            <View style={{ alignItems: 'center', flexDirection: 'row' }}>
                                <View style={{ flex: 0.8, flexDirection: 'row', alignItems: 'center' }}>
                                    <Text style={styles.usernameText}>{item.user_name}</Text>
                                    <Text style={styles.atUserName}> @{item.email}</Text>
                                </View>

                                <View style={{ flex: 0.2, alignItems: 'center' }}>
                                    <Text style={styles.textStyle}>
                                        <TimeAgo
                                            time={timestamp}
                                            style={styles.textStyle}
                                            hideAgo={true} />
                                    </Text>
                                </View>
                            </View>

                            {/* ............second View............. */}
                            <ViewMoreText
                                numberOfLines={1}
                                renderViewMore={this.renderViewMore}
                                renderViewLess={this.renderViewLess}
                            >
                                <Text style={styles.textContainStyle}>
                                    {/* text is only for one line then View-more,View-less not display */}
                                    {/* Lorem ipsum dolor sit amet, in quo dolorum ponderum, nam veri molestie constituto eu. Eum enim tantas sadipscing ne, ut omnes malorum nostrum cum. Errem populo qui ne, ea ipsum antiopam definitionem eos..... */}
                                    {description}
                                </Text>
                            </ViewMoreText>

                            {/* ............third View............. */}
                            <View style={[styles.iconViewStyle, { marginRight: 10 }]}>
                                <Image
                                    // source={{ uri: URLFeedImage + item.post_media[0].media_name }}
                                    resizeMode='stretch'
                                    style={styles.postImagestyle}
                                />
                            </View>

                            {/* ............Forth View............. */}
                            <View style={{ marginTop: Matrics.Scale(110), flexDirection: 'row', }}>
                                <View style={styles.iconViewStyle}>
                                    <Image
                                        source={Images.icon_fight}
                                        resizeMode='stretch'
                                        style={styles.iconStyle}
                                    />
                                    <Text style={styles.textStyle}> 000</Text>
                                </View>

                                <View style={styles.iconViewStyle}>
                                    <Image
                                        source={Images.icon_comment}
                                        resizeMode='stretch'
                                        style={styles.iconStyle}
                                    />
                                    <Text style={styles.textStyle}> 000</Text>
                                </View>

                                <View style={styles.downloadIconViewStyle}>
                                    <Image
                                        source={Images.icon_download}
                                        resizeMode='stretch'
                                        style={styles.iconStyle}
                                    />
                                </View>

                            </View>

                        </View>
                    </View>

                </Card>
            );
        })        
    }





    GalleryRenderItem() {
        return this.state.PostImages.map((item, index) => {
            console.log("item", item);
            console.log("CategoryIconPath:", URLFeedImage + item.media_name);
            return (
                <Card
                    key={index}
                    containerStyle={styles.cardStyle}>
                    <Lightbox>
                        <Image
                            source={{ uri: URLFeedImage + item.media_name }}
                            resizeMode='stretch'
                            style={styles.cardImageStyle}
                        />
                    </Lightbox>
                </Card>
            );
        })
    }

    render() {
        console.log("render PostImages:", this.state.PostImages);
        return (
            <View style={{ flex: 1, backgroundColor: 'black' }}>

                {
                    this.state.isPhotoVisible &&
                    <View style={styles.photoGallery}>
                        <TouchableOpacity onPress={() => { this.setState({ isPhotoVisible: false }) }}                            >
                            <Image
                                source={Images.icon_remove}
                                resizeMode='contain'
                                style={styles.photoVisibleStyle}
                            />
                        </TouchableOpacity>

                        <ScrollView horizontal={true}>
                            <View horizontal={true} style={{ flexDirection: 'row' }}>
                                {this.GalleryRenderItem()}
                            </View>
                        </ScrollView>
                    </View>
                }

                <ScrollView style={{ flex: 1 }}>
                    {this.rendarItem()}
                </ScrollView>

                {/* ..........add post button.......... */}
                <View style={styles.containerView}>
                    <TouchableOpacity onPress={() => this.props.navigation.navigate('WritePostScreen')} >
                        <Image
                            source={Images.icon_add}
                            resizeMode='contain'
                            style={styles.imageContainer}
                        />
                    </TouchableOpacity>
                </View>

                <LoadWheel isVisible={this.state.isLoading, this.state.isPhotosLoading} />
            </View >
        );
    }
};

const styles = StyleSheet.create({
    containerView: {
        margin: Matrics.Scale(20),
        alignSelf: 'flex-end',
        borderRadius: Matrics.Scale(60),
        position: 'absolute',
        bottom: 0,
    },
    photoGallery: {
        height: 170,
        borderBottomWidth: 0.5,
        borderBottomColor: Colors.TEXTCOLOR
    },
    photoVisibleStyle: {
        alignSelf: 'flex-end',
        marginTop: 10,
        marginRight: 10,
        height: Matrics.Scale(20),
        width: Matrics.Scale(23)
    },
    imageContainer: {
        width: Matrics.Scale(50),
        height: Matrics.Scale(50),
        // backgroundColor: 'red',
        borderRadius: Matrics.Scale(25),
        alignSelf: 'flex-end',
        justifyContent: 'center',
        marginRight: Matrics.Scale(20),
    },
    usernameText: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600'
    },
    atUserName: {
        color: Colors.TEXTCOLOR,
        fontSize: 14
    },
    textContainStyle: {
        color: 'white',
        fontSize: 12
    },
    viewMoreStyle: {
        color: Colors.LOGIN,
        fontSize: 12
    },
    textStyle: {
        color: Colors.TEXTCOLOR,
        fontSize: 12
    },
    postImagestyle: {
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        height: Matrics.Scale(130),
        width: width - Matrics.Scale(80),
    },
    iconViewStyle: {
        flexDirection: 'row',
        flex: 0.3,
        marginTop: 10,
        height: 20,
        width: 20
    },
    downloadIconViewStyle: {
        flex: 0.2,
        marginTop: 10,
        height: 20,
        width: 20
    },
    iconStyle: {
        height: Matrics.Scale(15),
        width: Matrics.Scale(18)
    },
    headerStyleNav: {
        flex: 1,
        color: Colors.LOGIN,
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
    headerImage: {
        height: Matrics.Scale(15),
        width: Matrics.Scale(20)
    },
    emptyListView: {
        flex: 1,
        backgroundColor: 'red',
        justifyContent: 'center',
        alignItems: 'center'
    },
    emptyText: {
        color: Colors.LOGIN,
        textAlign: 'center',
        fontSize: Matrics.Scale(17),
    },
    cardStyle:
    {
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 0,
        borderRadius: Matrics.Scale(10),
        height: Matrics.Scale(105),
        width: Matrics.Scale(105),
        flexDirection: 'row',
        backgroundColor: 'black',
    },
    cardImageStyle: {
        height: Matrics.Scale(105),
        width: Matrics.Scale(105),
        borderRadius: Matrics.Scale(10),
    },
    imageBackgroundContainer: {
        height: Platform.OS == 'ios' ? height / 4.8 : height / 4,
        width: width,
        // justifyContent : 'center',
        alignItems: 'center'
    },
    cardStyle2: {
        marginHorizontal: 0,
        backgroundColor: 'black',
        borderWidth: 0,
        borderBottomWidth: 0.3,
        borderBottomColor: Colors.TEXTCOLOR
    },
    profileStyle: {
        width: Matrics.Scale(50),
        height: Matrics.Scale(50),
        borderRadius: Matrics.Scale(25),
        // alignSelf: 'flex-end',
        justifyContent: 'center',
    }

});

const mapTostateProps = (state) => {
    console.log("Home::state::", state);
    return {
        home: state.Home,
        auth: state.Auth,
        encrypt: state.Encryption,
    }
}

export default connect(mapTostateProps, { getPostRequest, getPostImagesRequest })(HomeScreen);