import React, { Component } from 'react';
import { Text, View, StyleSheet } from 'react-native';

class PinterestLayoutScreen extends Component {
    render() {
        return (
            <View style={{ marginTop: 40 }}>
                <Text> Pinterest Layout Screen !!</Text>
                <Text> Pinterest Layout Screen !!</Text>
                <Text> Pinterest Layout Screen !!</Text>
                <Text> Pinterest Layout Screen !!</Text>
            </View>
        );
    }
};

const styles = StyleSheet.create({});

export default PinterestLayoutScreen;