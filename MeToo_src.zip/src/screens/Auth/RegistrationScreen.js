import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TextInput,
    ImageBackground,
    TouchableOpacity,
    Alert
} from 'react-native';
import { connect } from 'react-redux';
import { LoadWheel } from '../../components/common/LoadWheel';
import ImagePicker from 'react-native-image-crop-picker';
import { registerRequest, encryptTokenRequest } from '../../Redux/Actions';

import { Header, Button } from '../../components/common';
import { Colors, Images, Matrics } from '../../Assets';

class RegistrationScreen extends Component {
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Register',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        headerBackTitle: null,
        headerLeft:
            <TouchableOpacity onPress={() => navigation.goBack()}
                style={{ padding: Matrics.Scale(15) }}>
                <Image source={Images.back} style={styles.headerImage} />
            </TouchableOpacity>,
    });

    constructor(props) {
        super(props),
            this.state = {
                isLoading: false,
                profileImage: {},
                userName: "",
                email: "",
                password: "",
                guid: "",
                userToken: ""
            }
    }

    async componentWillReceiveProps(nextProps) {
        console.log("registerDetails NextProps:", nextProps);
        console.log("this.props:", this.props);

        if (nextProps.registerDetails.registration_Success &&
            nextProps.registerDetails.registrationData.status == "0" && this.state.isLoading) {
            this.setState({ isLoading: false })
            console.log("false 1");
            alert(nextProps.registerDetails.registrationData.message)
        }
        if (nextProps.registerDetails.registration_Success &&
            nextProps.registerDetails.registrationData.status == "1" && this.state.isLoading) {

            await this.setState({
                guid: nextProps.registerDetails.registrationData.data.User.guid,
                userToken: nextProps.registerDetails.registrationData.userToken, isLoading: false
            })

            await this.props.encryptTokenRequest({ guid: this.state.guid })
            console.log('enc NextProp:', nextProps);

            if (nextProps.encryptTokenDetail.encryptData.encrypted_value) {
                this.props.navigation.navigate('LoginScreen');
                this.setState({ isLoading: false, userName: "", email: "", password: "" })
            }
            else {
                this.setState({ isLoading: false })
                alert("Somthing Wrong in encryption token please try again")
            }

        } else if (!nextProps.registerDetails.registration_Success) {
            console.log('flase');
            await this.setState({ isLoading: false, userName: "", email: "", password: "" })
            alert(nextProps.registerDetails.registrationData.message)
        }
    }

    async onButtonPress() {
        console.log("this.props", this.props);

        console.log("register screen RefreshToken:", this.props.auth.refreshTokenData.tempToken);

        if (this.state.userName.trim() == "") {
            alert("Please enter username");
        }
        else if (this.state.email.trim() == "") {
            alert("Please enter email");
        }
        else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,5}$/i.test(this.state.email)) {
            alert("Please valid email");
        } else if (this.state.password.trim() == "") {
            alert("Please enter password");
        } else if (this.state.password.length <= 3) {
            alert("It is too short password, Please enter password more then 3 digits");
        }
        else {
            this.setState({ isLoading: true })

            this.props.registerRequest({
                secret_key: this.props.auth.refreshTokenData.tempToken,
                access_key: "nousername",
                device_token: "12345678",
                device_type: 1,
                username: this.state.userName,
                email: this.state.email,
                password: this.state.password,
                is_anonymous: "0",
                is_testdata: "1",
                profile_photo: this.state.profileImage.data
            })
        }
    }

    // select from gallery photos
    async choosePhoto() {
        console.log("in to choose gallery");

        ImagePicker.openPicker({
            compressImageQuality: 0.5,
            includeBase64: true
        }).then(async image => {
            console.log(image, 'consoleImage')
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? Images.user : image.filename, data: image.data }
            // let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? Images.user : image.filename, data: image.data }
            await this.setState({ profileImage: imgdata })
            console.log(this.state.profileImage, 'profileImage')
        });
    }

    //take a photo from camera
    async takePhoto() {
        ImagePicker.openCamera({
            cropping: true,
            compressImageQuality: 0.5,
            includeBase64: true

        }).then(async image => {
            // let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? 'IMG.jpg' : image.filename }
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? Images.user : image.filename }
            console.log(imgdata, 'imageData')
            await this.setState({ profileImage: imgdata })
        });
    }

    choosePhotoAlert() {

        Alert.alert(
            "User Profile",
            "Choose from gallery or click from camera.",
            [
                {
                    text: "Camera",
                    onPress: () => this.takePhoto(),
                },
                { text: "Gallery", onPress: () => this.choosePhoto() },
            ],
        );
    }

    render() {
        console.log(this.state.profileImage.uri, 'profileImageUri')
        console.log(this.props, 'this.props')
        return (
            <View style={styles.mainViewStyle}>

                <View style={styles.containerView}>

                    <TouchableOpacity onPress={() => this.choosePhotoAlert()}>
                        <ImageBackground
                            source={Images.imgeBG}
                            style={styles.imageBackgroundContainer}>
                            <Image source={{ uri: this.state.profileImage.uri }} style={styles.profilePic} />
                        </ImageBackground>
                    </TouchableOpacity>

                    <View style={styles.textInputView}>
                        <Image
                            style={styles.iconStyle}
                            source={Images.user}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.userName}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ userName: text })}
                            placeholder="Username"
                        />
                    </View>

                    <View style={styles.textInputView}>
                        <Image
                            style={styles.emailIconStyle}
                            source={Images.email}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.email}
                            keyboardType={'email-address'}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ email: text })}
                            placeholder="Email"
                        />
                    </View>

                    <View style={styles.textInputView}>
                        <Image
                            style={styles.iconStyle}
                            source={Images.Lock}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.password}
                            secureTextEntry
                            keyboardType={'numeric'}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ password: text })}
                            placeholder="Password"
                        />
                    </View>

                </View>


                <View style={styles.buttonView}>
                    <Button onPress={this.onButtonPress.bind(this)}>
                        Register
                </Button>

                    <View style={styles.footerTextView}>
                        <Text style={styles.testStyle}> Already have an account?</Text>
                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate('LoginScreen')}
                        >
                            <Text style={[styles.testStyle, { fontWeight: '600' }]}> LOGIN</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <LoadWheel isVisible={this.state.isLoading} />
            </View>

        );
    }
};
const styles = StyleSheet.create({
    mainViewStyle: {
        flex: 1,
        backgroundColor: 'black'
    },
    containerView: {
        alignItems: 'center'
    },
    imageBackgroundContainer: {
        width: Matrics.Scale(120),
        height: Matrics.Scale(120),
        alignItems: 'center',
        margin: Matrics.Scale(40)
    },
    iconStyle: {
        marginLeft: Matrics.Scale(10),
        height: Matrics.Scale(22),
        width: Matrics.Scale(18)
    },
    emailIconStyle: {
        marginLeft: Matrics.Scale(10),
        height: Matrics.Scale(18),
        width: Matrics.Scale(20)
    },
    textInputView: {
        width: '90%',
        borderWidth: Matrics.Scale(1.5),
        padding: Matrics.Scale(17),
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
        borderColor: Colors.TEXTCOLOR,
        borderRadius: Matrics.Scale(35),
        marginVertical: Matrics.Scale(8)
    },
    textInput: {
        // backgroundColor: 'red',
        color: 'white',
        flex: 1,
        marginLeft: Matrics.Scale(10),
        fontSize: Matrics.Scale(20),
    },
    buttonView: {
        position: 'absolute',
        bottom: Matrics.Scale(50),
        width: '100%'
    },
    testStyle: {
        fontSize: Matrics.Scale(16),
        color: Colors.TEXTCOLOR,
    },
    footerTextView: {
        marginVertical: Matrics.Scale(25),
        alignSelf: 'center',
        flexDirection: 'row'
    },
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
    headerImage: {
        height: Matrics.Scale(13),
        width: Matrics.Scale(18)
    },
    profilePic: {
        width: Matrics.Scale(120),
        height: Matrics.Scale(120),
        borderRadius: Matrics.Scale(60)
    },
});

const mapToStateProps = (state) => {
    console.log("Register state:", state);

    return {
        registerDetails: state.Register,
        auth: state.Auth,
        encryptTokenDetail: state.Encryption,
    }
}

export default connect(mapToStateProps, { registerRequest, encryptTokenRequest })(RegistrationScreen);
