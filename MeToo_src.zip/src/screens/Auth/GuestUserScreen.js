import React, { Component } from 'react';
import { Alert, Text, View, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux'

import { StackActions, NavigationActions } from 'react-navigation';
import { LoadWheel } from '../../components/common/LoadWheel';
import { Colors, Images, Matrics } from '../../Assets';
import { guestUserRequest, refreshTokenRequest } from '../../Redux/Actions';

class GuestUserScreen extends Component {

    constructor(props) {
        super(props),
            this.state = {
                isLoading: false,
                isRefresh: false,
            }
            this.RefreshTokenRequest();
    }

    
    async componentWillReceiveProps(nextProps) {
        console.log('NextProps:', nextProps);
        console.log("isLoading:", this.state.isLoading);

        //......refreshTokenRequest api Receive
        if (nextProps.auth.refreshToken_Success && nextProps.auth.refreshTokenData.status == "1" & this.state.isLoading) {
            // await AsyncStorage.setItem('refreshtoken', JSON.stringify(nextProps.auth.refreshTokenData.tempToken))
            console.log('in if condition');
            this.props.navigation.navigate('GuestUserScreen')

        } else if (nextProps.auth.refreshToken_Success == false) {
            alert('Something went wrong here, please try opening the app again.')
        }


        if (nextProps.auth.guestUser_Success && nextProps.auth.guestData.status == "1" && this.state.isLoading) {
            await this.setState({ isLoading: false })

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'TabBarNavigation' })],
            });
            this.props.navigation.dispatch(resetAction);

            // this.props.navigation.navigate('TabBarNavigation')

        } else if (nextProps.auth.guestUser_Success && nextProps.auth.guestData.status == "0" && this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(nextProps.auth.guestData.message)

        } else if (nextProps.auth.guestData.guestUser_Success == false) {
            await this.setState({ isLoading: false })
            alert(nextProps.auth.guestData.message)
        }

    }

    async RefreshTokenRequest() {
        await this.setState({ isRefresh: true })
        this.props.refreshTokenRequest({
            access_key: "nousername"
        })
    }

    async onButtonPress() {
        console.log("this.props", this.props);
        console.log("register screen RefreshToken:", this.props.auth.refreshTokenData.tempToken);

        this.setState({ isLoading: true })
        this.props.guestUserRequest({
            secret_key: this.props.auth.refreshTokenData.tempToken,
            access_key: "nousername",
            device_token: "12345678",
            device_type: 1,
            is_testdata: "1"
        })
    }

    render() {
        return (
            <View style={styles.mainViewStyle} >
                <Image
                    style={styles.imageStyle}
                    source={Images.MeToo}
                    resizeMode='stretch' />

                <View style={styles.seconView}>
                    <View style={styles.textView}>
                        <TouchableOpacity onPress={() => this.onButtonPress()}>
                            <Text style={styles.testStyle}>Share till you're Ready!</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={[styles.textView, { borderBottomWidth: 0, marginTop: 20 }]}>
                        <TouchableOpacity onPress={() => this.props.navigation.navigate('LoginScreen')}>
                            <Text style={styles.testStyle}>Login</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <LoadWheel isVisible={this.state.isLoading, this.state.isRefresh} />
            </View >
        );
    }
};

const styles = StyleSheet.create({
    mainViewStyle: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'black'
    },
    imageStyle: {
        alignSelf: 'center',
        marginTop: Matrics.Scale(110),
        height: Matrics.Scale(100),
        width: Matrics.Scale(280),
        marginBottom: Matrics.Scale(110),
    },
    buttonView: {
        position: 'absolute',
        bottom: 50,
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: Colors.LOGIN,
    },
    seconView: {
        marginHorizontal: 10,
        justifyContent: 'center',
        position: 'absolute',
        bottom: 50,
    },
    textView: {
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: Colors.LOGIN,
    },
    testStyle: {
        fontWeight: '500',
        fontSize: Matrics.Scale(18),
        color: Colors.LOGIN,
    },
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
});

const mapToStateProps = (state) => {
    console.log('state:', state);
    return {
        auth: state.Auth
    };
}

export default connect(mapToStateProps, { refreshTokenRequest, guestUserRequest })(GuestUserScreen);