import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, ScrollView, Platform, TextInput, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
// import AsyncStorage from '@react-native-community/async-storage';
import { StackActions, NavigationActions } from 'react-navigation';
import { Button } from '../../components/common'
import { LoadWheel } from '../../components/common/LoadWheel';
import { Colors, Images, Matrics } from '../../Assets';
import { loginRequest, encryptTokenRequest } from '../../Redux/Actions';

let deviceType = Platform.OS == 'ios' ? 1 : 0;

class LoginScreen extends Component {
    static navigationOptions = () => ({
        headerTitle: 'Login',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        headerLeft: null
    });

    constructor(props) {
        super(props),
            this.state = {
                email: "",
                password: "",
                // refresh_token: "",
                isLoading: false,
                encryptionLoader: false,
                forgotLoading: false,
                guid: "",
                userToken: "",
                encryptToken: ""
            }
    }

    async componentWillReceiveProps(nextProps) {
        console.log('NextProps:', nextProps);
        console.log("isLoading:", this.state.isLoading);
        
        if (nextProps.auth.login_Success && nextProps.auth.loginData.status == "0" &&
        this.state.isLoading) {
            await this.setState({ isLoading: false, password: "" })
            alert(nextProps.auth.loginData.message)
            
        } else if (nextProps.auth.login_Success && nextProps.auth.loginData.status == "1" && this.state.isLoading) {
           await this.setState({ isLoading: false, encryptionLoader: true });
            //...Request for encrypt token 
            await this.props.encryptTokenRequest({ guid: nextProps.auth.loginData.data.User.guid })
        }
        else if (nextProps.auth.login_Success && this.state.encryptionLoader && nextProps.encrypt.encryptToken_Success) {
            await this.setState({ encryptionLoader: false });
            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'CategoryScreen' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }
        else if (nextProps.auth.login_Success == false) {
            await this.setState({ isLoading: false, password: "" })
            alert(nextProps.auth.loginData.message)
        }

    }

    // login Api callling........
    async onButtonPress() {
        console.log("this.props", this.props);
        console.log("register screen RefreshToken:", this.props.auth.refreshTokenData.tempToken);

        if (this.state.email.trim() == "") {
            alert("Please enter email id");
        }
        else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,5}$/i.test(this.state.email)) {
            alert("Please enter valid email id");
        } else if (this.state.password.trim() == "") {
            alert("Please enter password");
        }

        else {
            this.setState({ isLoading: true })
            this.props.loginRequest({
                secret_key: this.props.auth.refreshTokenData.tempToken,
                access_key: "nousername",
                device_token: "12345678",
                device_type: deviceType,
                email: this.state.email.toLowerCase(),
                password: this.state.password,
                is_testdata: "1"
            })
        }

    }

    render() {
        return (
            <View style={styles.mainViewStyle}>

                <View style={styles.containerView}>
                    <Image
                        style={styles.imageStyle}
                        source={Images.MeToo}
                        resizeMode='stretch' />

                    <View style={styles.textInputView}>
                        <Image
                            style={styles.emailIconStyle}
                            source={Images.email}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.email}
                            keyboardType={'email-address'}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ email: text })}
                            placeholder="Email"
                        />
                    </View>

                    <View style={styles.textInputView}>
                        <Image
                            style={styles.iconStyle}
                            source={Images.Lock}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.password}
                            secureTextEntry
                            keyboardType={'numeric'}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ password: text })}
                            placeholder="Password"
                        />
                    </View>

                </View>

                <View style={styles.buttonView}>
                    {/* <Button onPress={this.onButtonPress.bind(this)}> */}
                    <Button onPress={() => this.onButtonPress()}>
                        Login
                    </Button>

                    <View style={styles.footerTextView}>
                        <Text style={styles.testStyle}> Dont have an account?</Text>
                        <TouchableOpacity
                            onPress={() => this.props.navigation.navigate('RegistrationScreen')}
                        >
                            <Text style={[styles.testStyle, { fontWeight: '600' }]}> REGISTER</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <LoadWheel isVisible={this.state.isLoading, this.state.encryptionLoader} />
            </View>
        );
    }
};

const styles = StyleSheet.create({
    mainViewStyle: {
        flex: 1,
        backgroundColor: 'black'
    },
    containerView: {
        alignItems: 'center'
    },
    imageStyle: {
        marginTop: Matrics.Scale(110),
        height: Matrics.Scale(100),
        width: Matrics.Scale(280),
        marginBottom: Matrics.Scale(110),
    },
    iconStyle: {
        marginLeft: Matrics.Scale(10),
        height: Matrics.Scale(22),
        width: Matrics.Scale(18)
    },
    emailIconStyle: {
        marginLeft: Matrics.Scale(10),
        height: Matrics.Scale(18),
        width: Matrics.Scale(20)
    },
    textInputView: {
        width: '90%',
        borderWidth: 1.5,
        padding: 17,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
        borderColor: Colors.TEXTCOLOR,
        borderRadius: Matrics.Scale(35),
        marginVertical: 8
    },
    textInput: {
        // backgroundColor: 'red',
        color: 'white',
        flex: 1,
        marginLeft: Matrics.Scale(10),
        fontSize: Matrics.Scale(20),
    },
    buttonView: {
        position: 'absolute',
        bottom: 0,
        width: '100%'
    },
    testStyle: {
        fontSize: Matrics.Scale(18),
        color: Colors.TEXTCOLOR,
    },
    footerTextView: {
        marginVertical: Matrics.Scale(25),
        alignSelf: 'center',
        flexDirection: 'row'
    },
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
    
});

const mapToStateProps = (state) => {
    console.log('Login Screen state:', state);
    return {
        auth: state.Auth,
        encrypt: state.Encryption,
    }
}

export default connect(mapToStateProps, { loginRequest, encryptTokenRequest })(LoginScreen);