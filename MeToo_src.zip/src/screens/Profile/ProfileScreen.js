import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, FlatList, Platform, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { Header, Button, CadSectionSubCategory } from '../../components/common';
import { Colors, Images, Matrics } from '../../Assets';

let deviceType = Platform.OS == 'ios' ? 1 : 0;
const { width, height } = Dimensions.get('window');

class ProfileScreen extends Component {
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Profile',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        headerLeft:
            <TouchableOpacity onPress={() => navigation.navigate('PrivacySettingScreen')}
                style={{ padding: Matrics.Scale(15) }}>
                <Image   resizeMode='contain' source={Images.icon_privacy} style={styles.headerImage} />
            </TouchableOpacity>,
         headerRight: <TouchableOpacity onPress={() => navigation.navigate('LoginScreen')}
         style={{ padding: Matrics.Scale(15) }}>
         <Image   resizeMode='contain' source={Images.icon_logout} resizeMode='contain' style={styles.headerImage}></Image>
     </TouchableOpacity>,
     headerBackTitle: null
    });   

    rendarItem() {
        return (
            <View style={{ flex: 1, flexDirection: 'row' }}>
                <View style={{ margin: Matrics.Scale(10), }}>
                    <Image
                        source={Images.user}
                        resizeMode='contain'
                        style={{ width: Matrics.Scale(50) }}
                    />
                </View>

                <View style={{ marginVertical: 10, marginRight: 10, flex: 1, }}>
                    {/* .........first text line.......... */}
                    <View style={{ alignItems: 'center', flexDirection: 'row' }}>
                        <View style={{ flex: 0.8, flexDirection: 'row', alignItems: 'center' }}>
                            <Text style={styles.usernameText}>user name </Text>
                            <Text style={styles.atUserName}>@username12</Text>
                        </View>

                        <View style={{ flex: 0.2, alignItems: 'center' }}>
                            <Text style={styles.textStyle}>00 hrs</Text>
                        </View>
                    </View>

                    {/* ............second View............. */}
                    <View>
                        <Text style={styles.textContainStyle}>
                            sgdfbghdgbhdghtdfbgdgdsfgdgdfsgdfbghdgbhdghtdfbgdgdsfgdgdfsgdfbghdgbhdghtdfbgdgdsfgdgdfsgdfbghdgbhdghtdfbgdgdsfgdgdfsgdfbghdgbhdghtdfbgdgdsfgdgdf
                    </Text>
                    </View>

                    {/* ............third View............. */}
                    <View style={[styles.iconViewStyle, { marginRight: 10 }]}>
                        <Image
                            source={Images.BG}
                            resizeMode='stretch'
                            style={styles.postImagestyle}
                        />
                    </View>

                    {/* ............Forth View............. */}
                    <View style={{marginTop:110, flexDirection: 'row', }}>
                        <View style={styles.iconViewStyle}>
                            <Image
                                source={Images.icon_fight}
                                resizeMode='stretch'
                                style={styles.iconStyle}
                            />
                            <Text style={styles.textStyle}> 000</Text>
                        </View>

                        <View style={styles.iconViewStyle}>
                            <Image
                                source={Images.icon_comment}
                                resizeMode='stretch'
                                style={styles.iconStyle}
                            />
                            <Text style={styles.textStyle}> 000</Text>
                        </View>

                        <View style={styles.downloadIconViewStyle}>
                            <Image
                                source={Images.icon_download}
                                resizeMode='stretch'
                                style={styles.iconStyle}
                            />
                        </View>

                    </View>


                </View>
            </View>
        );
    }


    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'black' }}>

                <View style={styles.mainContainer}>
                    <View style={{ flex: 0.75 }}>
                        <View style={{ margin: Matrics.Scale(10) }}>
                            <Image
                                source={Images.icon_add}
                                resizeMode='contain'
                                style={{
                                    height: Matrics.Scale(80),
                                    width: Matrics.Scale(80),
                                    backgroundColor: 'black',
                                    borderRadius: Matrics.Scale(40),
                                    marginVertical: Matrics.Scale(10)
                                }}
                            />

                            <Text style={styles.usernameText}>User Name</Text>
                            <Text style={styles.detailText}>email@afd.com</Text>
                            <Text style={styles.detailText}>+1234567890</Text>

                        </View>

                    </View>

                    <View style={{ flex: 0.25 }}>
                        <TouchableOpacity onPress={() => this.props.navigation.navigate('PrivacySettingScreen')}>
                            <View style={styles.editViewStyle}>
                                <Text style={styles.edit}>Edit</Text>
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>

                <ScrollView>
                    {this.rendarItem()}
                </ScrollView>

            </View>
        );
    }
};

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        marginLeft:10,
        justifyContent: 'center',
        flexDirection: 'row'
    },
    editViewStyle: {
        marginTop: Matrics.Scale(20),
        marginRight: Matrics.Scale(15),
        padding: Matrics.Scale(6),
        borderColor: Colors.TEXTCOLOR,
        borderWidth: Matrics.Scale(1),
        borderRadius: Matrics.Scale(20),
        alignItems: 'center',
        justifyContent: 'center'
    },
    edit: {
        color: Colors.TEXTCOLOR,
        fontWeight: '500'
    },
    usernameText: {
        color: 'white',
        fontSize: 15
    },
    detailText: {
        color: Colors.TEXTCOLOR,
        fontSize: 12
    },
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
    headerImage: {
        height: Matrics.Scale(20),
        width: Matrics.Scale(25)
    },
    cardContainerStyle: {
        borderWidth: 0,
        borderBottomColor: Colors.TEXTCOLOR,
        borderBottomWidth: 0.3,
        backgroundColor: 'black'
    },
    containerView: {
        margin: Matrics.Scale(20),
        alignSelf: 'flex-end',
        borderRadius: Matrics.Scale(60),
        position: 'absolute',
        bottom: 0,
    },
    photoGallery: {
        height: 150,
        borderBottomWidth: 0.5,
        borderBottomColor: Colors.TEXTCOLOR
    },
    photoVisibleStyle: {
        alignSelf: 'flex-end',
        marginTop: 10,
        marginRight: 10,
        height: Matrics.Scale(20),
        width: Matrics.Scale(23)
    },
    imageContainer: {
        width: Matrics.Scale(50),
        height: Matrics.Scale(50),
        // backgroundColor: 'red',
        borderRadius: Matrics.Scale(25),
        alignSelf: 'flex-end',
        justifyContent: 'center',
        marginRight: Matrics.Scale(20),
    },
    usernameText: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600'
    },
    atUserName: {
        color: Colors.TEXTCOLOR,
        fontSize: 14
    },
    textContainStyle: {
        color: 'white',
        fontSize: 12
    },
    textStyle: {
        color: Colors.TEXTCOLOR,
        fontSize: 12
    },
    postImagestyle: {
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        height: Matrics.Scale(130),
        width: width - Matrics.Scale(80),
    },
    iconViewStyle: {
        flexDirection: 'row',
        flex: 0.3,
        marginTop: 10,
        height: 20,
        width: 20
    },
    downloadIconViewStyle: {
        flex: 0.2,
        marginTop: 10,
        height: 20,
        width: 20
    },
    iconStyle: {
        height: Matrics.Scale(15),
        width: Matrics.Scale(18)
    },
    
    

});

export default ProfileScreen;