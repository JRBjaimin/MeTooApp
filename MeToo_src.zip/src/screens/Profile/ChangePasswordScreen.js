import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, TextInput, FlatList, Platform, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { Colors, Images, Matrics } from '../../Assets';
import { Button } from '../../components/common'
import { LoadWheel } from '../../components/common/LoadWheel';

class ChangePasswordScreen extends Component {
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Change Password',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        headerLeft:
            <TouchableOpacity onPress={() => navigation.navigate('ProfileScreen')}
                style={{ padding: Matrics.Scale(15) }}>
                <Image resizeMode='contain' source={Images.back} style={styles.headerImage} />
            </TouchableOpacity>,

        headerBackTitle: null
    });

    constructor(props) {
        super(props),
            this.state = {
                currentPassword: "",
                confirmPassword: "",
                password: "",
                // refresh_token: "",
                isLoading: false,
                encryptionLoader: false,
                forgotLoading: false,
                guid: "",
                userToken: "",
                encryptToken: ""
            }
    }


    render() {
        return (
            <View style={styles.mainViewStyle}>

                <View style={styles.containerView}>

                    <View style={styles.textInputView}>
                        <Image
                            style={styles.iconStyle}
                            source={Images.Lock}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.currentPassword}
                            secureTextEntry
                            keyboardType={'numeric'}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ currentPassword: text })}
                            placeholder="Current Password"
                        />
                    </View>

                    <View style={styles.textInputView}>
                        <Image
                            style={styles.iconStyle}
                            source={Images.Lock}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.password}
                            secureTextEntry
                            keyboardType={'numeric'}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ password: text })}
                            placeholder="New Password"
                        />
                    </View>


                    <View style={styles.textInputView}>
                        <Image
                            style={styles.iconStyle}
                            source={Images.Lock}
                            resizeMode='stretch' />
                        <TextInput
                            style={styles.textInput}
                            value={this.state.confirmPassword}
                            secureTextEntry
                            keyboardType={'numeric'}
                            placeholderTextColor={'#7F7F7F'}
                            onChangeText={text => this.setState({ confirmPassword: text })}
                            placeholder="Confirm Password"
                        />
                    </View>

                </View>

                <View style={styles.buttonView}>
                    {/* <Button onPress={this.onButtonPress.bind(this)}> */}
                    <Button onPress={() => this.onButtonPress()}>
                        Change
                    </Button>


                </View>

                <LoadWheel isVisible={this.state.isLoading, this.state.encryptionLoader} />
            </View>

        );
    }
};

const styles = StyleSheet.create({
    headerImage: {
        height: Matrics.Scale(20),
        width: Matrics.Scale(25)
    },
    mainViewStyle: {
        flex: 1,
        backgroundColor: 'black'
    },
    containerView: {
        marginTop: 10,
        alignItems: 'center'
    },
    iconStyle: {
        marginLeft: Matrics.Scale(10),
        height: Matrics.Scale(22),
        width: Matrics.Scale(18)
    },
    textInputView: {
        width: '90%',
        borderWidth: 1.5,
        padding: 17,
        alignItems: 'center',
        justifyContent: 'flex-start',
        flexDirection: 'row',
        borderColor: Colors.TEXTCOLOR,
        borderRadius: Matrics.Scale(35),
        marginVertical: 8
    },
    textInput: {
        color: 'white',
        flex: 1,
        marginLeft: Matrics.Scale(10),
        fontSize: Matrics.Scale(20),
    },
    buttonView: {
        marginTop: 20,
        width: '100%'
    },
    testStyle: {
        fontSize: Matrics.Scale(18),
        color: Colors.TEXTCOLOR,
    },
    footerTextView: {
        marginVertical: Matrics.Scale(25),
        alignSelf: 'center',
        flexDirection: 'row'
    },
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    }   
});

export default ChangePasswordScreen;