import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, FlatList, Platform, ScrollView, Dimensions, TouchableOpacity } from 'react-native';
import { Header, Button, CadSectionSubCategory } from '../../components/common';
import { Colors, Images, Matrics } from '../../Assets';


class PrivacySettingScreen extends Component {
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Privacy Setting',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        headerLeft:
            <TouchableOpacity onPress={() => navigation.navigate('ProfileScreen')}
                style={{ padding: Matrics.Scale(15) }}>
                <Image resizeMode='contain' source={Images.back} style={styles.headerImage} />
            </TouchableOpacity>,

        headerBackTitle: null
    });

    render() {
        return (
            <View style={styles.mainContain}>

                <View style={{ flexDirection: 'row' }}>

                    <View style={styles.viewStyle1}>
                        <Text style={styles.textStyle1}> Profile Privacy Setting </Text>
                        <Text style={styles.viewStyle2}> Do you want to  Protect your profile</Text>
                    </View>
                    <View style={styles.viewStyle2}>
                        <Image
                            source={Images.icon_setting}
                            resizeMode='contain'
                            style={{
                                height: Matrics.Scale(25),
                                width: Matrics.Scale(38)
                            }}
                        />
                    </View>
                </View>
                <TouchableOpacity
                    onPress={() => this.props.navigation.navigate('ChangePasswordScreen')}
                >
                    <View style={{ flexDirection: 'row' }}>
                        <View style={styles.viewStyle1}>
                            <Text style={styles.textStyle1}> Change Password </Text>
                        </View>
                        <View style={styles.viewStyle2}>

                            <Image
                                source={Images.right}
                                resizeMode='contain'
                                style={{
                                    height: Matrics.Scale(15),
                                    width: Matrics.Scale(28)
                                }}
                            />
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        );
    }
};

const styles = StyleSheet.create({
    mainContain: {
        flex: 1,
        backgroundColor: 'black'
    },
    viewStyle1: {
        marginLeft: Matrics.Scale(10),
        flex: 0.8,
        justifyContent: 'center',
        height: Matrics.Scale(90),
        borderBottomColor: Colors.TEXTCOLOR,
        borderBottomWidth: 0.2
    },
    viewStyle2: {
        flexDirection: 'row',
        flex: 0.2,
        // backgroundColor: 'yellow',
        justifyContent: 'center',
        alignItems: 'center',
        height: Matrics.Scale(90),
        borderBottomWidth: 0.2,
        borderBottomColor: Colors.TEXTCOLOR,
        marginRight: Matrics.Scale(10),
    },
    textStyle1: {
        color: 'white',
        fontWeight: '500',
        fontSize: Matrics.Scale(18)
    },
    textStyle2: {
        color: Colors.TEXTCOLOR,
        fontSize: Matrics.Scale(14)
    },
    headerImage: {
        height: Matrics.Scale(20),
        width: Matrics.Scale(25)
    },
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },


});

export default PrivacySettingScreen;