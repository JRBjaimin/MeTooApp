import React, { Component } from 'react';
import { View, StyleSheet, Image, Platform, TouchableOpacity, FlatList } from 'react-native';
import { CadSectionSubCategory } from '../../components/common';
import { connect } from 'react-redux'
import { Colors, Images, Matrics } from '../../Assets';
import { CategoryIconPath } from '../../Config/Constants';

var SubCategoryDetailsOld = [
    { title: "Bullying", icon: Images.icon_Bully },
    { title: "Cyber Attack", icon: Images.icon_cyber_attack },
    { title: "Discrimination", icon: Images.icon_discriminstion },
    { title: "Sexual Harassment", icon: Images.icon_Sexual_Harassment },
    { title: "Verbal Abuse", icon: Images.icon_Abuse },
    { title: "Violence", icon: Images.icon_violence }
]

class SubCategoryScreen extends Component {
    constructor(props) {
        super(props),
            this.state = {
                SubCategoryDetails: [],
            }
        console.log("subcategory this.props", this.props);
    }

    static navigationOptions = ({ navigation }) =>
        ({
            headerTitle: navigation.state.params.data,
            headerTitleStyle: styles.headerStyleNav,
            headerStyle: { color: 'white', backgroundColor: 'black' },
            headerBackTitle: null,
            headerLeft:
                <TouchableOpacity onPress={() => navigation.goBack()}
                    style={{ padding: Matrics.Scale(15) }}>
                    <Image source={Images.back} style={styles.headerImage} />
                </TouchableOpacity>,
        });

    async componentDidMount() {
        console.log("prop of sub cate:", this.props);
        await this.setState({ SubCategoryDetails: this.props.navigation.state.params.subCategory[0].SubCategory })
        console.log("SubCategoryDetails:", this.state.SubCategoryDetails);
    }

    renderItem(item) {
        console.log("SubCategoryDetails item::", item);
        console.log("CategoryIconPath:", CategoryIconPath + item.item.category_image);
        return (
            <CadSectionSubCategory
                onPress={() => this.props.navigation.navigate('HomeScreen', { dataFromId: item.item })}
                onPressDetail={() => this.props.navigation.navigate('DetailOfSubCategoryScreen', { data: item.item })}
                title={item.item.name}
                source={{ uri: CategoryIconPath + item.item.category_image }} />
        );
    }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'black' }}>
                <FlatList
                    data={this.state.SubCategoryDetails}
                    extraData={this.state}
                    renderItem={this.renderItem.bind(this)}
                />
            </View>
        );
    }
};

const styles = StyleSheet.create({
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
    headerImage: {
        height: Matrics.Scale(13),
        width: Matrics.Scale(18)
    },
});

export default SubCategoryScreen;