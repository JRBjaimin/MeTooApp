import React, { Component } from 'react';
import { Text, View, StyleSheet, Image, ScrollView, ImageBackground, TouchableOpacity, FlatList } from 'react-native';
import { Header, Button, CadSectionSubCategory } from '../../components/common';

import { CategoryIconPath } from '../../Config/Constants';
import { Colors, Images, Matrics } from '../../Assets';

class DetailOfSubCategoryScreen extends Component {
    static navigationOptions = ({ navigation }) =>
        ({
            headerTitle: navigation.state.params.data.name,
            headerTitleStyle: styles.headerStyleNav,
            headerStyle: { color: 'white', backgroundColor: 'black' },
            headerBackTitle: null,
            headerLeft:
                <TouchableOpacity onPress={() => navigation.goBack()}
                    style={{ padding: Matrics.Scale(15) }}>
                    <Image source={Images.back} style={styles.headerImage} />
                </TouchableOpacity>,
        });

    constructor(props) {
        super(props),
            this.state = {
                SubCatImage: this.props.navigation.state.params.data.category_image,
                SubCatTitle: this.props.navigation.state.params.data.name,
                Terms: this.props.navigation.state.params.data.terms_of_harresment ? this.props.navigation.state.params.data.terms_of_harresment : "No Data Found",
                Situations: this.props.navigation.state.params.data.situations ? this.props.navigation.state.params.data.situations : "No Data Found"
            }
        console.log("Detail sub screen this.props.", this.props);
    }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'black' }}>

                <View style={styles.containerView}>
                    <Image
                        source={{ uri: CategoryIconPath + this.state.SubCatImage }}
                        resizeMode='contain'
                        style={styles.imageContainer}
                    />
                </View>

                <ScrollView>
                    <View style={styles.viewStyle}>
                        <Text style={styles.testTiyleStyle}>
                            The terms of {this.state.SubCatTitle}
                        </Text>

                        <Text style={styles.textDetailStyle}>
                            {this.state.Terms}
                        </Text>

                        <Text style={styles.testTiyleStyle}>
                            Situations
                        </Text>

                        <View style={{ flexDirection: 'row' }}>
                            <Image
                                source={Images.icon_point}
                                resizeMode='contain'
                                style={styles.iconStyle}
                            />
                            <Text style={styles.textDetailStyle}>
                                {this.state.Situations}
                            </Text>
                        </View>

                    </View>
                </ScrollView>

            </View>
        );
    }
};

const styles = StyleSheet.create({
    containerView: {
        margin: Matrics.Scale(40),
        alignSelf: 'center',
        justifyContent: 'center',
        height: Matrics.Scale(120),
        width: Matrics.Scale(120),
        borderWidth: 0.1,
        borderRadius: Matrics.Scale(60),
        backgroundColor: '#161616',
        // backgroundColor: 'yellow',
    },
    imageContainer: {
        width: Matrics.Scale(70),
        height: Matrics.Scale(70),
        // backgroundColor: 'red',
        justifyContent: 'center',
        alignSelf: 'center',
    },
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
    headerImage: {
        height: Matrics.Scale(13),
        width: Matrics.Scale(18)
    },
    viewStyle: {
        margin: Matrics.Scale(20)
    },
    testTiyleStyle: {
        color: Colors.LOGIN,
        fontWeight: '700',
        fontSize: Matrics.Scale(20)
    },
    textDetailStyle: {
        marginTop: Matrics.Scale(7),
        marginBottom: Matrics.Scale(23),
        color: Colors.TEXTCOLOR,
        fontWeight: '500'
    },
    iconStyle: {
        marginTop: Matrics.Scale(10),
        height: Matrics.Scale(10),
        width: Matrics.Scale(10),
        marginRight: Matrics.Scale(10),
    }
});

export default DetailOfSubCategoryScreen;