import React, { Component } from 'react';
import { View, StyleSheet, Image, FlatList, Platform, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux'
import { Colors, Images, Matrics } from '../../Assets';
import { CategoryIconPath } from '../../Config/Constants';
import { LoadWheel } from '../../components/common/LoadWheel';
import { CardSection } from '../../components/common';
import { categoryRequest } from '../../Redux/Actions';

let deviceType = Platform.OS == 'ios' ? 1 : 0;

var CategoryDetailsOld = [
    { title: "Work", icon: Images.work },
    { title: "Home", icon: Images.home },
    { title: "School", icon: Images.school },
    { title: "Public", icon: Images.public }
]

class CategoryScreen extends Component {
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Category',
        headerTitleStyle: styles.headerStyleNav,
        headerStyle: { backgroundColor: 'black' },
        headerBackTitle: null,
        headerLeft:
            <TouchableOpacity onPress={() => navigation.navigate('LoginScreen')}
                style={{ padding: Matrics.Scale(15) }}>
                <Image source={Images.back} style={styles.headerImage} />
            </TouchableOpacity>,
    });

    constructor(props) {
        super(props),
            this.state = {
                isLoading: false,
                CategoryDetails: [],
            }
    }

    UNSAFE_componentWillMount() {
        console.log("category screen");
        this.categoryRequest();
    }

    async componentWillReceiveProps(nextProps) {
        console.log("Category NextProps:", nextProps);

        if (nextProps.category.category_Success && nextProps.category.categoryData.status == "1" &&
            this.state.isLoading) {
            await this.setState({ CategoryDetails: nextProps.category.categoryData.data.Category })
            console.log("CategoryDetails:", this.state.CategoryDetails);
            this.setState({ isLoading: false })
        } else if (nextProps.category.category_Success && nextProps.category.categoryData.status == "0" &&
            this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(nextProps.category.categoryData.message)
        } else if (nextProps.category.category_Success == false){
            await this.setState({ isLoading: false })
            alert(nextProps.category.categoryData.message)
        }

    }

    categoryRequest() {
        console.log("this.props", this.props);
        console.log("userToken:", this.props.auth.loginData.userToken);
        console.log("encrypted_value:", this.props.encrypt.encryptData.encrypted_value);

        this.setState({ isLoading: true })
        this.props.categoryRequest({
            secret_key: this.props.auth.loginData.userToken,
            access_key: this.props.encrypt.encryptData.encrypted_value,
            device_token: "12345678",
            device_type: deviceType,
            is_testdata: "1"
        })
    }

    renderItem(item) {
        console.log("CategoryDetails item::", item);
        console.log("CategoryIconPath:", CategoryIconPath + item.item.category_image);
        return (
            <CardSection
                key="item"
                onPress={() => this.props.navigation.navigate('SubCategoryScreen', { data: item.item.name, subCategory: this.state.CategoryDetails })}
                title={item.item.name}
                source={{ uri: CategoryIconPath + item.item.category_image }} />
        );
    }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: 'black' }}>

                <FlatList
                    data={this.state.CategoryDetails}
                    extraData={this.state}
                    renderItem={this.renderItem.bind(this)}
                />

                <LoadWheel isVisible={this.state.isLoading} />
            </View>
        );
    }
};
const styles = StyleSheet.create({
    headerStyleNav: {
        flex: 1,
        color: 'white',
        fontSize: Matrics.Scale(16),
        textAlign: 'center',
        alignSelf: 'center',
    },
    headerImage: {
        height: Matrics.Scale(13),
        width: Matrics.Scale(18)
    },
});

const mapToStateProps = (state) => {
    console.log("::state::", state);
    return {
        category: state.Category,
        auth: state.Auth,
        encrypt: state.Encryption,
    }
}

export default connect(mapToStateProps, { categoryRequest })(CategoryScreen);

