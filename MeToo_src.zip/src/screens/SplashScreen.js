import React, { Component } from 'react';
import { Text, View, Image, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { connect } from 'react-redux';
// import { LoadWheel } from '../components/common/LoadWheel';

import { Colors, Images, Matrics } from '../Assets';
// import { StackActions, NavigationActions } from "react-navigation";
// import { refreshTokenRequest } from '../Redux/Actions';

class SplashScreen extends Component {

    constructor(props) {
        super(props),
            this.state = {
                refresh_token: '',
                isLoading: false,
            }
        this.TimeOut();
    }

    async componentWillReceiveProps(nextProps) {
        console.log('NextProps:', nextProps);
        // if (nextProps.auth.refreshToken_Success && nextProps.auth.refreshTokenData.status == "1" & this.state.isLoading) {
        //     await AsyncStorage.setItem('refreshtoken', JSON.stringify(nextProps.auth.refreshTokenData.tempToken))
        //     console.log('in if condition');
        //     this.props.navigation.navigate('GuestUserScreen')

        // } else if (!nextProps.auth.refreshToken_Success) {
        //     alert('Something went wrong here, please try opening the app again.')
        // }
    }

    TimeOut() {
        setTimeout(() => {
            // this.setState({ isLoading: true })
            // this.props.refreshTokenRequest({
            //     access_key: "nousername"
            // })
            this.props.navigation.navigate('GuestUserScreen')
        }, 2000);
    }

    render() {
        return (
            <View style={styles.mainViewStyle} >
                <Image
                    style={styles.imageStyle}
                    source={Images.MeToo}
                    resizeMode='stretch' />

                {/* <LoadWheel isVisible={this.state.isLoading, this.state.encryptionLoader} /> */}
            </View>
        );
    }
};

const styles = StyleSheet.create({
    mainViewStyle: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'black'
    },
    imageStyle: {
        marginTop: Matrics.Scale(110),
        height: Matrics.Scale(100),
        width: Matrics.Scale(280),
        marginBottom: Matrics.Scale(110),
    },
    buttonView: {
        position: 'absolute',
        bottom: 50,
        // width: '100%',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: Colors.LOGIN,
    },
    testStyle: {
        fontSize: Matrics.Scale(18),
        color: Colors.LOGIN,
    },
});

// const mapToStateProps = (state) => {
//     // console.log('state:', state);

//     return {
//         auth: state.Auth
//     };
// }

export default connect(null)(SplashScreen);