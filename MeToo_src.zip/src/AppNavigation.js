import React, { Component } from 'react';
import { View, Text, Image } from 'react-native';
import { createAppContainer } from "react-navigation";
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { createStackNavigator, HeaderBackButton } from 'react-navigation-stack';
import { Colors, Images, Matrics } from './Assets';

// Assets
import SplashScreen from './screens/SplashScreen';
import GuestUserScreen from './screens/Auth/GuestUserScreen';
import LoginScreen from './screens/Auth/LoginScreen';
import RegistrationScreen from './screens/Auth/RegistrationScreen';
import CategoryScreen from './screens/Category/CategoryScreen';
import DetailOfSubCategoryScreen from './screens/Category/DetailOfSubCategoryScreen';
import SubCategoryScreen from './screens/Category/SubCategoryScreen';
//home tab...(1)
import HomeScreen from './screens/Home/HomeScreen';
import WritePostScreen from './screens/Home/WritePostScreen';
import PinterestLayoutScreen from './screens/Home/PinterestLayoutScreen';
//notification tab...(2)
import NotificationScreen from './screens/Notification/NotificationScreen';
//chat tab...(3)
import ChatScreen from './screens/Chat/ChatScreen';
//profile tab...(4)
import ProfileScreen from './screens/Profile/ProfileScreen';
import EditProfileScreen from './screens/Profile/EditProfileScreen';
import PrivacySettingScreen from './screens/Profile/PrivacySettingScreen';
import ChangePasswordScreen from './screens/Profile/ChangePasswordScreen';

const OtherStack = createStackNavigator(
    {
        ProfileScreen: {
            screen: ProfileScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        EditProfileScreen: {
            screen: EditProfileScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        PrivacySettingScreen: {
            screen: PrivacySettingScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        ChangePasswordScreen: {
            screen: ChangePasswordScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
    }
);

const HomeStack = createStackNavigator(
    {
        HomeScreen: { screen: HomeScreen },
        WritePostScreen: {
            screen: WritePostScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        PinterestLayoutScreen: {
            screen: PinterestLayoutScreen,
            navigationOptions: () => ({
                // header: null
            })
        }
    }
);

const NotificationStack = createStackNavigator(
    {
        NotificationScreen: { screen: NotificationScreen },
    }
);

const ChatStack = createStackNavigator(
    {
        ChatScreen: { screen: ChatScreen, navigationOptions: () => ({ header: null }) },
    }
);

const ProfileStack = createStackNavigator(
    {
        ProfileScreen: {
            screen: ProfileScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        EditProfileScreen: {
            screen: EditProfileScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        PrivacySettingScreen: {
            screen: PrivacySettingScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        ChangePasswordScreen: {
            screen: ChangePasswordScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
    }
);

const TabBarNavigation = createBottomTabNavigator(
    {
        Home: {
            screen: HomeStack,
            navigationOptions: () => ({
                tabBarLabel: 'Home',
            })
        },
        Notification: {
            screen: NotificationStack,
            navigationOptions: () => ({
                tabBarLabel: 'Notification',
            })
        },
        Chat: {
            screen: ChatStack,
            navigationOptions: () => ({
                tabBarLabel: 'Chat',
            }),
        },
        Profile: {
            screen: ProfileStack,
            navigationOptions: () => ({
                tabBarLabel: 'Profile',
            }),
        },

    },
    {
        defaultNavigationOptions: ({ navigation }) => ({
            tabBarIcon: ({ focused }) => {
                const { routeName } = navigation.state;
                let iconName;
                if (routeName === 'Home') {
                    iconName = focused ? Images.icon_Home : Images.icon_Home_G;
                    return <Image source={iconName} style={{ height: 20, width: 22 }} resizeMode='stretch' />
                } else if (routeName === 'Notification') {
                    iconName = focused ? Images.icon_Alarm : Images.icon_Alarm_G;
                    return <Image source={iconName} style={{ height: 20, width: 18 }} resizeMode='stretch' />
                } else if (routeName === 'Chat') {
                    iconName = focused ? Images.icon_chat : Images.icon_chat_G;
                    return <Image source={iconName} style={{ height: 20, width: 22 }} resizeMode='stretch' />
                } else if (routeName === 'Profile') {
                    iconName = focused ? Images.icon_profile : Images.icon_profile_G;
                    return <Image source={iconName} style={{ height: 20, width: 18 }} resizeMode='stretch' />
                }
            },
        }),
        tabBarOptions: {
            activeTintColor: Colors.LOGIN,
            style: { backgroundColor: 'black' },
            showLabel: false
        },
        swipeEnabled: false
    }

)

const AppNavigation = createStackNavigator(
    {
        SplashScreen: {
            screen: SplashScreen,
            navigationOptions: () => ({
                header: null
            })
        },
        GuestUserScreen: {
            screen: GuestUserScreen,
            navigationOptions: () => ({
                header: null
            })
        },
        LoginScreen: {
            screen: LoginScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        RegistrationScreen: {
            screen: RegistrationScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        CategoryScreen: {
            screen: CategoryScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        DetailOfSubCategoryScreen: {
            screen: DetailOfSubCategoryScreen,
            navigationOptions: () => ({
                // header: null
            })
        },
        SubCategoryScreen: {
            screen: SubCategoryScreen,
            navigationOptions: () => ({
                // header: null
            })
        },

        TabBarNavigation: {
            screen: TabBarNavigation,
            navigationOptions: () => ({
                header: null,
                gesturesEnabled: false
            })
        },
    },
    {
        initialRouteName: "SplashScreen"
        // initialRouteName: "TabBarNavigation"
    }
);

export default createAppContainer(AppNavigation);