const images = {
  //App Logo  
  MeToo: require('../Assets/Images/Auth/meToLogo.png'),

  //header
  back: require('../Assets/Images/Auth/back.png'),
  metoo: require('../Assets/Images/Home/header_Me_Too.png'),

  // Home Tab Images
  icon_add: require('../Assets/Images/Home/icon_add.png'),
  icon_remove: require('../Assets/Images/Home/icon_remove.png'),
  icon_List: require('../Assets/Images/Home/icon_List.png'),
  icon_layout: require('../Assets/Images/Home/icon_layout.png'),
  icon_comment: require('../Assets/Images/Home/icon_comment.png'),
  icon_download: require('../Assets/Images/Home/icon_download.png'),

  // Bottom Tab
  icon_Home: require('../Assets/Images/Home/icon_Home.png'),
  icon_Home_G: require('../Assets/Images/Home/icon_Home_G.png'),
  icon_Alarm_G: require('../Assets/Images/Home/icon_Alarm_G.png'),
  icon_Alarm: require('../Assets/Images/Home/icon_Alarm.png'),
  icon_chat_G: require('../Assets/Images/Home/icon_chat_G.png'),
  icon_chat: require('../Assets/Images/Home/icon_chat.png'),
  icon_profile: require('../Assets/Images/Home/icon_profile.png'),
  icon_profile_G: require('../Assets/Images/Home/icon_profile_G.png'),
  icon_fight: require('../Assets/Images/Home/icon_fight.png'),
  BG: require('../Assets/Images/Home/BG.png'),
  user: require('../Assets/Images/Home/user.png'),

  //Login Screen & Register Screen Images
  email: require('../Assets/Images/Auth/icon_email.png'),
  phone: require('../Assets/Images/Auth/phone.png'),
  Lock: require('../Assets/Images/Auth/Lock.png'),
  user: require('../Assets/Images/Auth/user.png'),
  imgeBG: require('../Assets/Images/Auth/imgeBG.png'),

  // category
  home: require('../Assets/Images/Category/icon_home.png'),
  school: require('../Assets/Images/Category/icon_school.png'),
  public: require('../Assets/Images/Category/icon_public.png'),
  right: require('../Assets/Images/Category/icon_Right.png'),
  work: require('../Assets/Images/Category/icon_work.png'),
  icon_point: require('../Assets/Images/Category/icon_point.png'),

  //subCategory
  icon_Detail: require('../Assets/Images/SubCategory/icon_privacyPolicy.png'),
  icon_Abuse: require('../Assets/Images/SubCategory/icon_Abuse.png'),
  icon_Bully: require('../Assets/Images/SubCategory/icon_Bully.png'),
  icon_cyber_attack: require('../Assets/Images/SubCategory/icon_cyber_attack.png'),
  icon_discriminstion: require('../Assets/Images/SubCategory/icon_discriminstion.png'),
  icon_Sexual_Harassment: require('../Assets/Images/SubCategory/icon_Sexual_Harassment.png'),
  icon_violence: require('../Assets/Images/SubCategory/icon_violence.png'),

  // profile
  icon_logout: require('../Assets/Images/Profile/icon_logout.png'),
  icon_privacy: require('../Assets/Images/Profile/icon_privacy.png'),
  icon_setting: require('../Assets/Images/Profile/icon_setting.png'),

};

export default images;
