const Colors = {
  // (LOGIN button is Yellow color)
  LOGIN: '#FF9103',
  WHITE: "#FFF",
  TEXTCOLOR: '#7F7F7F',
  background_CS: '#161616'

};
export default Colors;
