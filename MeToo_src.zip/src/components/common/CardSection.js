import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Colors, Matrics, Images } from '../../Assets'

const CardSection = (props) => {
  console.log(props, "props>>>");

  return (
    <TouchableOpacity onPress={props.onPress}>

      <View style={styles.containerStyle} >

        {/* ..................left............... */}
        <View style={styles.leftRightView}>
          <Image
            style={styles.backImageStyle}
            source={props.source}
            resizeMode='stretch' />
        </View>

        {/* ..................center............... */}
        <View style={styles.centerView}>
          <Text style={styles.textStyle} >{props.title}</Text>
        </View>

        {/* ..................Right............... */}
        <View style={styles.leftRightView}>
          <Image
            style={[styles.iconStyle, { marginLeft: 23 }]}
            source={Images.right}
            resizeMode='stretch' />
        </View>

      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  containerStyle: {
    borderWidth: 1,
    backgroundColor: Colors.background_CS,
    // borderColor: 'white',
    height: Matrics.Scale(60),
    marginTop: Matrics.Scale(15),
    marginHorizontal: Matrics.Scale(17),
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    borderRadius: 5
  },
  leftRightView: {
    // backgroundColor: 'yellow',
    alignItems: 'center',
    flex: 0.2,
  },
  centerView: {
    alignItems: 'flex-start',
    flex: 0.6,
    marginLeft: 5
  },
  textStyle: {
    fontSize: Matrics.Scale(17),
    color: 'white',
    fontWeight: '600'
  },
  backImageStyle: {
    // marginLeft: Matrics.Scale(10),
    height: Matrics.Scale(28),
    width: Matrics.Scale(30)
  },
  iconStyle: {
    justifyContent: 'center',
    height: Matrics.Scale(9),
    width: Matrics.Scale(5)
  }
});

export { CardSection };
