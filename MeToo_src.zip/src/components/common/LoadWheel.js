//Libraries
import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import Spinner from 'react-native-spinkit';
//Assets
const { height, width } = Dimensions.get('window')

export const LoadWheel = ({ isVisible }) => {
    return (
        <View style={{
            position: 'absolute',
            justifyContent: 'center',
            backgroundColor: 'rgba(52, 52, 52, 0.6)',
            height: isVisible ? '100%' : 0,
            width: isVisible ? '100%' : 0,
            alignItems: 'center'
        }}>
            <Spinner
                isVisible={isVisible}
                size={50}
                type={'WanderingCubes'}
                color='white'
            />
        </View>
    )
}