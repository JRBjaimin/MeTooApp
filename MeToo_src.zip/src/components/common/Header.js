import React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Matrics, Images, Colors } from '../../Assets';


const Header = (props) => {
  const { textStyle, viewStyle } = styles;

  return (
    <View style={viewStyle}>

      {/* ..................left............... */}
      <View style={styles.leftRightView}>
        <TouchableOpacity
          onPress={props.onPress}
        >
          <Image
            style={styles.backImageStyle}
            source={props.source}
            resizeMode='stretch' />
        </TouchableOpacity>
      </View>

      {/* ..................center............... */}
      <View style={styles.centerView}>
        <Text style={[textStyle, { color: props.headerText === "Me Too" ? Colors.LOGIN : 'white' }]}>{props.headerText}</Text>
      </View>

      {/* ..................Right............... */}
      <View style={styles.leftRightView}>
        <Text style={textStyle}>{props.headerTextRight}</Text>
      </View>

    </View>

  );
};

const styles = StyleSheet.create({
  viewStyle: {
    backgroundColor: 'black',
    alignItems: 'center',
    height: Matrics.Scale(60),
    paddingTop: Matrics.Scale(30),
    paddingTop: Matrics.Scale(20),
    shadowColor: '#1C1C1C',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    elevation: Matrics.Scale(2),
    position: 'relative',
    borderBottomColor: "#1C1C1C",
    borderBottomWidth: 0.7,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leftRightView: {
    // backgroundColor: 'yellow',
    alignItems: 'center',
    flex: 0.2
  },
  centerView: {
    alignItems: 'center',
    flex: 0.6
  },
  textStyle: {
    fontSize: Matrics.Scale(17),
    // color: 'white',
    fontWeight: '600'
  },
  backImageStyle: {
    marginLeft: Matrics.Scale(10),
    height: Matrics.Scale(13),
    width: Matrics.Scale(18)
  }
});

export { Header };
