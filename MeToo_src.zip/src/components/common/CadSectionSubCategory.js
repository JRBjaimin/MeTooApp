import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Colors, Matrics, Images } from '../../Assets'

const CadSectionSubCategory = (props) => {
  console.log(props, "CadSectionSubCategory props>>>");

  return (

    <View>
      <TouchableOpacity style={styles.containerStyle} onPress={props.onPress}>

        {/* ..................left............... */}
        <View style={styles.leftView}>
          <Image
            style={styles.backImageStyle}
            source={props.source}
            resizeMode='contain' />
        </View>

        {/* ..................center............... */}
        <View style={styles.centerView}>
          <Text style={styles.textStyle} >{props.title}</Text>
        </View>


        {/* ..................Right............... */}
        <View style={styles.RightView}>
          <TouchableOpacity onPress={props.onPressDetail}
            style={styles.RightTuchView}>
            <Image
              style={styles.iconStyle}
              source={Images.icon_Detail}
              resizeMode='contain' />
          </TouchableOpacity>
        </View>

      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  containerStyle: {
    borderWidth: 1,
    backgroundColor: 'white',
    height: Matrics.Scale(62),
    marginTop: Matrics.Scale(15),
    marginHorizontal: Matrics.Scale(17),
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    borderRadius: Matrics.Scale(5)
  },
  leftView: {
    // backgroundColor: 'pink',
    alignItems: 'center',
    flex: 0.2,
  },
  RightView: {
    // backgroundColor: 'pink',
    flex: 0.2,
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    paddingLeft: Matrics.Scale(30)
  },
  RightTuchView: {
    height: Matrics.Scale(28),
    width: Matrics.Scale(30),
    // backgroundColor: 'green',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  centerView: {
    alignItems: 'flex-start',
    flex: 0.6,
    // backgroundColor: 'yellow'
  },
  textStyle: {
    marginLeft: Matrics.Scale(5),
    fontSize: Matrics.Scale(14),
    color: Colors.LOGIN,
    fontWeight: '600'
  },
  backImageStyle: {
    height: Matrics.Scale(42),
    width: Matrics.Scale(34)
  },
  iconStyle: {
    justifyContent: 'center',
    alignSelf: 'center',
    height: Matrics.Scale(17),
    width: Matrics.Scale(4)
  }
});

export { CadSectionSubCategory };
