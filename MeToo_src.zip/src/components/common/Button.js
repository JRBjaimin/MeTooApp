import React from 'react';
import { Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Colors, Matrics } from '../../Assets'

export const Button = ({ onPress, children }) => {
  const { buttonStyle, textStyle } = styles;

  return (
    <TouchableOpacity onPress={onPress} style={buttonStyle}>
      <Text style={textStyle}>
        {children}
      </Text>
    </TouchableOpacity>
  );
};

export const MainButton = ({ onPress, Title, contentContainer }) => {
  return (
      <TouchableOpacity style={[styles.buttonStyle, contentContainer]} onPress={onPress}>
          <Text style={styles.textStyle}>{Title}</Text>
      </TouchableOpacity>
  )
}

const styles = StyleSheet.create({
  textStyle: {
    alignSelf: 'center',
    justifyContent: 'center',
    color: 'white',
    fontSize: Matrics.Scale(18),
    fontWeight: '600',
  },
  buttonStyle: {
    alignSelf: 'center',
    width: '90%',
    height: Matrics.Scale(60),
    backgroundColor: Colors.LOGIN,
    borderRadius: Matrics.Scale(35),
    borderWidth: Matrics.Scale(1),
    justifyContent: 'center',
  },
});

// export { Button };
