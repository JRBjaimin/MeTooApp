export const ImagePath = 'http://clientapp.narola.online/pg/MeTooHaven/WS/'


export const URLProfileImage = ImagePath + "profile_image/"
export const CategoryIconPath = ImagePath + "category_image/"
export const URLFeedImage = ImagePath + "post_image/"
export const URLFeedVideo = ImagePath + "post_video/"
