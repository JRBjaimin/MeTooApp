// Library
import { Platform } from 'react-native';
// import { TWILIO_API_KEY } from './Constants'

const LIVE = 'http://clientapp.narola.online/pg/MeTooHaven/WS/MeTooHaven.php?Service='  //main url endpoint

const ENVIRONMENT = LIVE

module.exports = {
    //====================REFRESH TOKEN==================//

    RefreshToken(params) {
        console.log(params, 'params FOR TOKEN')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}RefreshToken`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================ENCRYPT TOKEN==================//

    TestEncryption(params) {
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}TestEncryption`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { console.log("TestEncryption Api response", response), setTimeout(() => null, 0); return response.json() })
        // .then((response) => { setTimeout(() => null, 0); return response.json() })

    },



    //====================USER LOGIN API==================//

    userLogin(params) {

        console.log(params, 'params on api')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"
        return fetch(`${ENVIRONMENT}Login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },
            body: JSON.stringify(params)
        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
        // .then((response) => { console.log("response::::", response) })
    },

    //====================LOGOUT USER API==================//

    logoutUser(params) {
        console.log(params, 'api params logout>>>>>>>>>>>>>>>>>>>>>>>>')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}Logout`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================USER REGISTER API==================//

    Register(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}Register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================FORGOT PASSWORD==================//

    forgotPassword(params) {

        console.log(params, 'params on api')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"
        return fetch(`${ENVIRONMENT}ForgotPassword`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },
            body: JSON.stringify(params)
        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },
    //====================GUEST USER==================//

    registerAsGuestUser(params) {

        console.log(params, 'params on api')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"
        return fetch(`${ENVIRONMENT}RegisterAsGuestUser`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },
            body: JSON.stringify(params)
        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    //====================Category List==================//

    getCategory(params) {
        console.log(params, 'params FOR TOKEN')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}GetCategory`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },


    //====================[1.] HOME TAB ==================//
    //====================Home Get Post==================//

    getPostsByCategory(params) {
        console.log(params, 'params FOR TOKEN')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}GetPostsByCategory`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================Home Get Post Images==================//

    getPostImages(params) {
        console.log(params, 'params FOR TOKEN')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}GetPostImages`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

}  
