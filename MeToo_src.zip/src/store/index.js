//LIBRARIES
import { applyMiddleware, createStore, compose } from 'redux';
import createSagaMiddleware from 'redux-saga';
import { persistStore, persistReducer } from 'redux-persist'
import logger from 'redux-logger'
import storage from '@react-native-community/async-storage';
//ASSETS
import rootSaga from '../Redux/Sagas';
import rootReducer from '../Redux/Reducers';

const persistConfig = {
    key: 'root',
    storage,
}

// Middleware
const sagaMiddleware = createSagaMiddleware();

const middleware = [sagaMiddleware, logger];

const persistedReducer = persistReducer(persistConfig, rootReducer)

export const Store = createStore(
    persistedReducer,
    compose(
        (applyMiddleware(...middleware))
    ));

export const Persistor = persistStore(Store)
sagaMiddleware.run(rootSaga);

///////////////////////////////////////////////////////////////

// import { createStore, compose, applyMiddleware } from 'redux';
// // i am using thunk , alternative of logger
// import thunk from 'redux-thunk';
// //LIBRARIES
// import { persistStore, persistReducer } from 'redux-persist'
// //Note:- import storage from 'redux-persist/lib/storage'
// import AsyncStorage from '@react-native-community/async-storage';
// //ASSETS
// import reducers from '../redux/reducers';

// const persistConfig = {
//     key: 'root',
//     storage: AsyncStorage,
// }

// // const middleware = [];

// const persistedReducer = persistReducer(persistConfig, reducers)

// export const store = createStore(
//     persistedReducer,
//     {},
//     compose(
//         applyMiddleware(thunk)
//     ));

// export const persistor = persistStore(store)





// // =========================================
// // export default { store, persistor };

// // persistStore(store, { storage: storage, whitelist: ['likedJobs'] })
// // let persistor = persistStore(store)
// // return { store, persistor }

// // ------------------------
// // const store = createStore(
// //     persistedReducer,
// //     {},
// //     compose(
// //         applyMiddleware(thunk),
// //         // autoRehydrate()
// //     )
// // );

// // persistStore(store, { storage: AsyncStorage, whitelist: ['likedJobs'] })
// // console.log('AsyncStorage>>>', AsyncStorage);

// // export default store;